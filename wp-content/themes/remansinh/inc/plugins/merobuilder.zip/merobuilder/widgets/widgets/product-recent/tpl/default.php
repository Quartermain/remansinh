<?php

		echo do_shortcode('[recent_products per_page="'.esc_attr($instance['per_page']).'" columns="'.esc_attr($instance['columns']).'" ]');
?>