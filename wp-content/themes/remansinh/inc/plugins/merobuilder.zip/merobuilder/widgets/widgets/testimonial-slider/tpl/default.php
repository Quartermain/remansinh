<?php
echo do_shortcode('[testimonial_slider]')
?>